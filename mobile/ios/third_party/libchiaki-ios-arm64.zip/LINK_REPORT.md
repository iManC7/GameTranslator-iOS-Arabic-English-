# iOS bağlama kanıtı

- Tarih (UTC): 2026-11-15T17:30:30Z
- Xcode: Xcode 26.6 Build version 17F113 
- SDK: 26.5 (/Applications/Xcode_26.6.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk)
- En düşük iOS: 13.0

## libgt_ios_linktest.dylib
```
/Users/runner/work/GameTranslator/GameTranslator/work/ios-native/build/libgt_ios_linktest.dylib: Mach-O 64-bit dynamically linked shared library arm64
 platform IOS
    minos 13.0
      sdk 26.5
çözülmemiş (sistemden gelecek) sembol sayısı: 220
bağlı sistem kütüphaneleri:
	@rpath/libgt_ios_linktest.dylib (compatibility version 0.0.0, current version 0.0.0)
	/usr/lib/libSystem.B.dylib (compatibility version 1.0.0, current version 1356.0.0)
	/System/Library/Frameworks/SystemConfiguration.framework/SystemConfiguration (compatibility version 1.0.0, current version 1405.120.5)
	/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation (compatibility version 150.0.0, current version 5026.5.4)
	/System/Library/Frameworks/CoreServices.framework/CoreServices (compatibility version 1.0.0, current version 1226.0.0)
```
dışa açık: _gt_ios_linktest_probe
## gt_ios_linktest_exe
```
/Users/runner/work/GameTranslator/GameTranslator/work/ios-native/build/gt_ios_linktest_exe.app/gt_ios_linktest_exe: Mach-O 64-bit executable arm64
 platform IOS
    minos 13.0
      sdk 26.5
çözülmemiş (sistemden gelecek) sembol sayısı: 220
bağlı sistem kütüphaneleri:
	/usr/lib/libSystem.B.dylib (compatibility version 1.0.0, current version 1356.0.0)
	/System/Library/Frameworks/SystemConfiguration.framework/SystemConfiguration (compatibility version 1.0.0, current version 1405.120.5)
	/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation (compatibility version 150.0.0, current version 5026.5.4)
	/System/Library/Frameworks/CoreServices.framework/CoreServices (compatibility version 1.0.0, current version 1226.0.0)
```
## Bağlayıcı haritası (dylib): arşiv başına bağlanan nesne sayısı
```
örnek satırlar:
[  2] chiaki-lib/libchiaki.a(common.c.o)
[  3] chiaki-lib/libchiaki.a(sock.c.o)
[  4] chiaki-lib/libchiaki.a(session.c.o)
libchiaki.a            39
libjerasure.a          3
libgf_complete.a       9
libprotobuf-nanopb.a   3
libcurl.a              92
libjson-c.a            9
libminiupnpc.a         14
libevent_core.a        11
libssl.a               79
libcrypto.a            850
libchiaki.a içinden: discovery, regist, session, holepunch, takion, streamconnection bağlandı
```
## Bağımsız bağlama (yalnız out/include + out/lib/libgtchiaki_ios.a)
```
ek bağlayıcı bayrakları: -framework SystemConfiguration -framework CoreFoundation -framework CoreServices
/Users/runner/work/GameTranslator/GameTranslator/work/ios-native/build/standalone/libgt_standalone.dylib: Mach-O 64-bit dynamically linked shared library arm64
```
## libgt_standalone.dylib
```
/Users/runner/work/GameTranslator/GameTranslator/work/ios-native/build/standalone/libgt_standalone.dylib: Mach-O 64-bit dynamically linked shared library arm64
 platform IOS
    minos 13.0
      sdk 26.5
çözülmemiş (sistemden gelecek) sembol sayısı: 220
bağlı sistem kütüphaneleri:
	@rpath/libgt_standalone.dylib (compatibility version 0.0.0, current version 0.0.0)
	/System/Library/Frameworks/SystemConfiguration.framework/SystemConfiguration (compatibility version 1.0.0, current version 1405.120.5)
	/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation (compatibility version 150.0.0, current version 5026.5.4)
	/System/Library/Frameworks/CoreServices.framework/CoreServices (compatibility version 1.0.0, current version 1226.0.0)
	/usr/lib/libSystem.B.dylib (compatibility version 1.0.0, current version 1356.0.0)
```
## Çıktılar
```
total 48760
-rw-r--r--  1 runner  staff    636064 Nov 15 17:30 libchiaki.a
-rw-r--r--  1 runner  staff   8673624 Nov 15 17:30 libcrypto.a
-rw-r--r--  1 runner  staff    889272 Nov 15 17:30 libcurl.a
-rw-r--r--  1 runner  staff    225472 Nov 15 17:30 libevent_core.a
-rw-r--r--  1 runner  staff    175272 Nov 15 17:30 libgf_complete.a
-rw-r--r--  1 runner  staff  12468008 Nov 15 17:30 libgtchiaki_ios.a
-rw-r--r--  1 runner  staff     72288 Nov 15 17:30 libjerasure.a
-rw-r--r--  1 runner  staff     87768 Nov 15 17:30 libjson-c.a
-rw-r--r--  1 runner  staff     74136 Nov 15 17:30 libminiupnpc.a
-rw-r--r--  1 runner  staff     29200 Nov 15 17:30 libprotobuf-nanopb.a
-rw-r--r--  1 runner  staff   1605808 Nov 15 17:30 libssl.a
46 başlık dosyası (include/)
```

SONUÇ: BAŞARILI — libchiaki ve bağımlılıkları iOS arm64 (iphoneos) için derlendi ve bağlandı.
